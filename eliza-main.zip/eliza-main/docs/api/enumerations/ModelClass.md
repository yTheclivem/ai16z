# Enumeration: ModelClass

## Enumeration Members

### SMALL

> **SMALL**: `"small"`

#### Defined in

[packages/core/src/types.ts:75](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L75)

***

### MEDIUM

> **MEDIUM**: `"medium"`

#### Defined in

[packages/core/src/types.ts:76](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L76)

***

### LARGE

> **LARGE**: `"large"`

#### Defined in

[packages/core/src/types.ts:77](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L77)

***

### EMBEDDING

> **EMBEDDING**: `"embedding"`

#### Defined in

[packages/core/src/types.ts:78](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L78)

***

### IMAGE

> **IMAGE**: `"image"`

#### Defined in

[packages/core/src/types.ts:79](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L79)
