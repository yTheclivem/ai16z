# Function: getEndpoint()

> **getEndpoint**(`provider`): `string`

## Parameters

• **provider**: [`ModelProviderName`](../enumerations/ModelProviderName.md)

## Returns

`string`

## Defined in

[packages/core/src/models.ts:226](https://github.com/ai16z/eliza/blob/main/packages/core/src/models.ts#L226)
