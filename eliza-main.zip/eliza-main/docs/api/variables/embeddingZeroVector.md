# Variable: embeddingZeroVector

> `const` **embeddingZeroVector**: `any`[]

## Defined in

[packages/core/src/memory.ts:10](https://github.com/ai16z/eliza/blob/main/packages/core/src/memory.ts#L10)
