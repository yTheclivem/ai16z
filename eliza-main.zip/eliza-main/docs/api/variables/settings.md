# Variable: settings

> `const` **settings**: `ProcessEnv`

## Defined in

[packages/core/src/settings.ts:54](https://github.com/ai16z/eliza/blob/main/packages/core/src/settings.ts#L54)
