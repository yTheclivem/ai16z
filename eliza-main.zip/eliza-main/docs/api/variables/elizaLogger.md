# Variable: elizaLogger

> `const` **elizaLogger**: `ElizaLogger`

## Defined in

[packages/core/src/logger.ts:270](https://github.com/ai16z/eliza/blob/main/packages/core/src/logger.ts#L270)
