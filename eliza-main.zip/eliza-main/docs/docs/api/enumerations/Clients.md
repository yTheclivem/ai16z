# Enumeration: Clients

## Enumeration Members

### DIRECT

> **DIRECT**: `"direct"`

#### Defined in

[packages/core/src/types.ts:324](https://github.com/ai16z/eliza/blob/8b230e97279ce98a641d3338cbfa78f13130c60e/packages/core/src/types.ts#L324)

---

### DISCORD

> **DISCORD**: `"discord"`

#### Defined in

[packages/core/src/types.ts:323](https://github.com/ai16z/eliza/blob/8b230e97279ce98a641d3338cbfa78f13130c60e/packages/core/src/types.ts#L323)

---

### TELEGRAM

> **TELEGRAM**: `"telegram"`

#### Defined in

[packages/core/src/types.ts:326](https://github.com/ai16z/eliza/blob/8b230e97279ce98a641d3338cbfa78f13130c60e/packages/core/src/types.ts#L326)

---

### TWITTER

> **TWITTER**: `"twitter"`

#### Defined in

[packages/core/src/types.ts:325](https://github.com/ai16z/eliza/blob/8b230e97279ce98a641d3338cbfa78f13130c60e/packages/core/src/types.ts#L325)
