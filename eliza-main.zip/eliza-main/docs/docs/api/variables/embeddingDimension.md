# Variable: embeddingDimension

> `const` **embeddingDimension**: `1536` = `1536`

## Defined in

[packages/core/src/memory.ts:9](https://github.com/ai16z/eliza/blob/8b230e97279ce98a641d3338cbfa78f13130c60e/packages/core/src/memory.ts#L9)
