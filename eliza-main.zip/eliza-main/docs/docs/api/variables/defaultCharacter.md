# Variable: defaultCharacter

> `const` **defaultCharacter**: [`Character`](../type-aliases/Character.md)

## Defined in

[packages/core/src/defaultCharacter.ts:3](https://github.com/ai16z/eliza/blob/8b230e97279ce98a641d3338cbfa78f13130c60e/packages/core/src/defaultCharacter.ts#L3)
