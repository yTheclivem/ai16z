# Variable: evaluationTemplate

> `const` **evaluationTemplate**: `string`

Template used for the evaluation generateText.

## Defined in

[packages/core/src/evaluators.ts:8](https://github.com/ai16z/eliza/blob/8b230e97279ce98a641d3338cbfa78f13130c60e/packages/core/src/evaluators.ts#L8)
