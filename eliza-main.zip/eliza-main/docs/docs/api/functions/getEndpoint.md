# Function: getEndpoint()

> **getEndpoint**(`provider`): `string`

## Parameters

• **provider**: [`ModelProviderName`](../enumerations/ModelProviderName.md)

## Returns

`string`

## Defined in

[packages/core/src/models.ts:188](https://github.com/ai16z/eliza/blob/8b230e97279ce98a641d3338cbfa78f13130c60e/packages/core/src/models.ts#L188)
